//
//  practiceApp.swift
//  practice
//
//  Created by user232369 on 4/2/23.
//

import SwiftUI

@main
struct practiceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
